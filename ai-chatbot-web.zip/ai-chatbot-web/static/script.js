// script.js
// Handles two things:
// 1. Sending the user's question to /chat and displaying the reply
// 2. Sending feedback to /feedback
// No other functionality is added.

const chatWindow = document.getElementById("chat-window");
const chatForm = document.getElementById("chat-form");
const userInput = document.getElementById("user-input");

const feedbackForm = document.getElementById("feedback-form");
const feedbackInput = document.getElementById("feedback-input");
const feedbackStatus = document.getElementById("feedback-status");

function addMessage(text, sender) {
  const msg = document.createElement("div");
  msg.classList.add("message", sender === "user" ? "user-message" : "bot-message");
  msg.textContent = text;
  chatWindow.appendChild(msg);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const message = userInput.value.trim();
  if (!message) return;

  addMessage(message, "user");
  userInput.value = "";

  addMessage("Thinking...", "bot");

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();

    // Remove the "Thinking..." placeholder
    chatWindow.removeChild(chatWindow.lastChild);
    addMessage(data.response, "bot");
  } catch (error) {
    chatWindow.removeChild(chatWindow.lastChild);
    addMessage("Error: could not reach the server.", "bot");
  }
});

feedbackForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const feedbackText = feedbackInput.value.trim();
  if (!feedbackText) return;

  try {
    const response = await fetch("/feedback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feedback: feedbackText }),
    });

    const data = await response.json();

    if (data.status === "success") {
      feedbackStatus.textContent = "Thank you! Your feedback has been saved.";
      feedbackInput.value = "";
    } else {
      feedbackStatus.textContent = "Feedback could not be empty.";
    }
  } catch (error) {
    feedbackStatus.textContent = "Error: could not submit feedback.";
  }
});
